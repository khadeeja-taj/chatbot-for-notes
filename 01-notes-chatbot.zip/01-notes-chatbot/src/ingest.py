"""
Ingest notes into a searchable index.

Reads every .txt, .md and .pdf file under a folder, splits each into
overlapping chunks, fits a TF-IDF model over all chunks, and saves the
whole thing to a single pickle the chatbot can load instantly.

Usage:
    python src/ingest.py --notes ./notes --out ./index.pkl
"""
import argparse
import glob
import os
import pickle
import re

from sklearn.feature_extraction.text import TfidfVectorizer


def read_pdf(path: str) -> str:
    from pypdf import PdfReader
    reader = PdfReader(path)
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def read_file(path: str) -> str:
    if path.lower().endswith(".pdf"):
        return read_pdf(path)
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def chunk_text(text: str, size: int = 900, overlap: int = 150):
    """Split on paragraph-ish boundaries, then pack into ~`size`-char chunks."""
    text = re.sub(r"\n{3,}", "\n\n", text.strip())
    pieces = re.split(r"\n\s*\n", text)
    chunks, buf = [], ""
    for p in pieces:
        p = p.strip()
        if not p:
            continue
        if len(buf) + len(p) + 2 <= size:
            buf = (buf + "\n\n" + p).strip()
        else:
            if buf:
                chunks.append(buf)
            # carry a little overlap so context isn't cut mid-thought
            tail = buf[-overlap:] if buf else ""
            buf = (tail + "\n\n" + p).strip() if tail else p
    if buf:
        chunks.append(buf)
    return chunks


def build_index(notes_dir: str, out_path: str):
    paths = []
    for ext in ("txt", "md", "pdf"):
        paths += glob.glob(os.path.join(notes_dir, "**", f"*.{ext}"), recursive=True)
    paths = sorted(set(paths))
    if not paths:
        raise SystemExit(f"No .txt/.md/.pdf files found under {notes_dir!r}")

    chunks, sources = [], []
    for path in paths:
        text = read_file(path)
        for i, ch in enumerate(chunk_text(text)):
            chunks.append(ch)
            sources.append(f"{os.path.basename(path)}#chunk{i}")

    print(f"Read {len(paths)} files -> {len(chunks)} chunks")

    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2),
                                 max_features=50000)
    matrix = vectorizer.fit_transform(chunks)

    with open(out_path, "wb") as f:
        pickle.dump(
            {"chunks": chunks, "sources": sources,
             "vectorizer": vectorizer, "matrix": matrix},
            f,
        )
    print(f"Index saved to {out_path}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--notes", default="./notes", help="folder of your notes")
    ap.add_argument("--out", default="./index.pkl", help="where to save the index")
    args = ap.parse_args()
    build_index(args.notes, args.out)
