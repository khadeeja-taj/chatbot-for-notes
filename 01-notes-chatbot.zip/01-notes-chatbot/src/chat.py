"""
Chat over your notes using the index built by ingest.py.

Retrieval is always local (TF-IDF cosine similarity). Answer generation is
optional: if you set an LLM_API_KEY it will write a grounded answer that cites
the chunks; if you don't, it runs in "extractive" mode and just shows you the
most relevant passages. That means a grader can run it with zero API setup.

Usage:
    python src/chat.py --index ./index.pkl
    python src/chat.py --index ./index.pkl --ask "what is the attendance policy?"

Optional env vars for generated answers (any OpenAI-compatible API):
    LLM_API_KEY   = your key
    LLM_BASE_URL  = e.g. https://api.openai.com/v1  (or Groq/Together/local)
    LLM_MODEL     = e.g. gpt-4o-mini
"""
import argparse
import os
import pickle

from sklearn.metrics.pairwise import cosine_similarity


def load_index(path: str):
    with open(path, "rb") as f:
        return pickle.load(f)


def retrieve(index, query: str, k: int = 4):
    qv = index["vectorizer"].transform([query])
    scores = cosine_similarity(qv, index["matrix"])[0]
    order = scores.argsort()[::-1][:k]
    return [(index["chunks"][i], index["sources"][i], float(scores[i]))
            for i in order if scores[i] > 0]


def generate_answer(query: str, hits):
    key = os.getenv("LLM_API_KEY")
    if not key:
        return None  # signal: fall back to extractive mode

    from openai import OpenAI
    client = OpenAI(api_key=key,
                    base_url=os.getenv("LLM_BASE_URL", "https://api.openai.com/v1"))
    context = "\n\n".join(f"[{i+1}] (from {s})\n{c}"
                          for i, (c, s, _) in enumerate(hits))
    prompt = (
        "Answer the question using ONLY the context below. "
        "Cite sources inline like [1], [2]. If the answer isn't in the "
        "context, say you don't know.\n\n"
        f"Context:\n{context}\n\nQuestion: {query}\nAnswer:"
    )
    resp = client.chat.completions.create(
        model=os.getenv("LLM_MODEL", "gpt-4o-mini"),
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1,
    )
    return resp.choices[0].message.content.strip()


def answer(index, query: str, k: int = 4):
    hits = retrieve(index, query, k)
    if not hits:
        print("No relevant passages found in your notes.\n")
        return
    gen = generate_answer(query, hits)
    if gen:
        print("\n" + gen + "\n")
    else:
        print("\n(No LLM_API_KEY set — showing the most relevant passages)\n")
        for i, (c, s, score) in enumerate(hits, 1):
            print(f"[{i}] {s}  (score {score:.2f})\n{c}\n")
    print("Sources: " + ", ".join(s for _, s, _ in hits) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--index", default="./index.pkl")
    ap.add_argument("--ask", default=None, help="one-shot question; omit for REPL")
    ap.add_argument("-k", type=int, default=4, help="chunks to retrieve")
    args = ap.parse_args()

    index = load_index(args.index)

    if args.ask:
        answer(index, args.ask, args.k)
        return

    print("Ask about your notes. Ctrl-C or empty line to quit.\n")
    try:
        while True:
            q = input("you > ").strip()
            if not q:
                break
            answer(index, q, args.k)
    except (KeyboardInterrupt, EOFError):
        print()


if __name__ == "__main__":
    main()
