# 📒 Notes Chatbot — RAG over your course notes

A small, honest RAG (Retrieval-Augmented Generation) system that answers
questions using **your own notes or university handbook** instead of the
model's general knowledge.

> Door 1, Project 01: *"A chatbot that knows your notes."*

## What it does

1. **Ingest** — reads every `.txt`, `.md`, and `.pdf` in a folder, splits them
   into overlapping chunks, and builds a TF-IDF search index.
2. **Retrieve** — for each question, finds the most relevant chunks by cosine
   similarity. This part is 100% local, no API key, no internet.
3. **Answer** — if you provide an LLM key, it writes a grounded answer that
   **cites the source chunks**. If you don't, it runs in *extractive mode* and
   simply shows the passages that answer your question.

## Why it's built this way

- **Runs with zero setup for a grader.** Retrieval needs no API key, so anyone
  can clone this and see it work in under a minute.
- **Citations are mandatory.** The prompt forces the model to answer only from
  retrieved context and cite `[1][2]`. This is the point of RAG — no hallucinated
  policies about your own handbook.
- **Provider-agnostic.** Any OpenAI-compatible endpoint works (OpenAI, Groq,
  Together, or a local model server) via two env vars.

## Quick start

```bash
pip install -r requirements.txt

# Put your notes in ./notes (a sample handbook is included)
python src/ingest.py --notes ./notes --out ./index.pkl

# Ask a question
python src/chat.py --index ./index.pkl --ask "what is the attendance policy?"

# ...or chat interactively
python src/chat.py --index ./index.pkl
```

### Optional: generated answers

```bash
export LLM_API_KEY="sk-..."
export LLM_BASE_URL="https://api.openai.com/v1"   # or Groq, Together, local
export LLM_MODEL="gpt-4o-mini"
python src/chat.py --index ./index.pkl --ask "how is the final grade calculated?"
```

## What I found

- TF-IDF retrieval is surprisingly strong for structured documents like a
  handbook, where the answer usually shares vocabulary with the question. It
  struggles on paraphrased questions ("can I miss classes?" vs "attendance"),
  which is exactly where swapping in dense embeddings would help next.
- Chunk size is the main knob. Too small and a policy gets split across chunks;
  too large and retrieval gets noisy. ~900 chars with 150 overlap worked best
  on the sample handbook.

## Next steps

- [ ] Swap TF-IDF for sentence-embedding retrieval (hybrid search)
- [ ] Add a small web UI (Streamlit) instead of the terminal
- [ ] Return the exact sentence, not just the chunk

## Layout

```
├── notes/              # drop your .txt / .md / .pdf here
├── src/ingest.py       # build the index
├── src/chat.py         # query the index
└── requirements.txt
```
