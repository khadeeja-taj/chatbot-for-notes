# Student Handbook (sample)

## Attendance
Students must maintain at least 75% attendance in every course. Falling below
75% makes a student ineligible to sit the final examination for that course.
Medical absences require a certificate submitted within 7 days.

## Grading
The grading scale is: A (85-100), B (70-84), C (55-69), D (40-54), F (below 40).
The final grade is 40% coursework (assignments and quizzes), 20% midterm, and
40% final examination.

## Final Year Project (FYP)
The FYP spans two semesters. A proposal must be approved by the supervisor and
the department committee before work begins. The final deliverable is a report,
a working demo, and a viva voce. Plagiarism above 19% similarity is rejected.

## Library
Books can be borrowed for 14 days and renewed twice if no one else has reserved
them. Late returns are fined 10 rupees per day per book.
